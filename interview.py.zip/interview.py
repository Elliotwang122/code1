import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Ball settings
BALL_RADIUS = 20
BALL_COLOR_1 = (255, 0, 0)  # Red
BALL_COLOR_2 = (0, 0, 255)  # Blue

# Ball class
class Ball:
    def __init__(self, x, y, vx, vy, color):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color

    def move(self):
        self.x += self.vx
        self.y += self.vy
        self.check_wall_collision()

    def check_wall_collision(self):
        if self.x - BALL_RADIUS <= 0 or self.x + BALL_RADIUS >= SCREEN_WIDTH:
            self.vx = -self.vx
        if self.y - BALL_RADIUS <= 0 or self.y + BALL_RADIUS >= SCREEN_HEIGHT:
            self.vy = -self.vy

    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), BALL_RADIUS)

def check_ball_collision(ball1, ball2):
    dx = ball1.x - ball2.x
    dy = ball1.y - ball2.y
    distance = (dx**2 + dy**2) ** 0.5

    if distance <= 2 * BALL_RADIUS:
        ball1.vx, ball2.vx = ball2.vx, ball1.vx
        ball1.vy, ball2.vy = ball2.vy, ball1.vy

# Create the screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Bouncing Balls")

# Create balls
ball1 = Ball(random.randint(BALL_RADIUS, SCREEN_WIDTH - BALL_RADIUS),
             random.randint(BALL_RADIUS, SCREEN_HEIGHT - BALL_RADIUS),
             random.choice([-1, 1]) * random.uniform(1, 3),
             random.choice([-1, 1]) * random.uniform(1, 3),
             BALL_COLOR_1)

ball2 = Ball(random.randint(BALL_RADIUS, SCREEN_WIDTH - BALL_RADIUS),
             random.randint(BALL_RADIUS, SCREEN_HEIGHT - BALL_RADIUS),
             random.choice([-1, 1]) * random.uniform(1, 3),
             random.choice([-1, 1]) * random.uniform(1, 3),
             BALL_COLOR_2)

# Main loop
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Move balls
    ball1.move()
    ball2.move()

    # Check collision between balls
    check_ball_collision(ball1, ball2)

    # Draw everything
    screen.fill((255, 255, 255))  # White background
    ball1.draw(screen)
    ball2.draw(screen)
    pygame.display.flip()

    # Cap the frame rate
    clock.tick(60)

pygame.quit()
